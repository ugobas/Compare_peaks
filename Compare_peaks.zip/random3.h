/*
	File: random3.h
	
	Revision: Jun 06, 2000
*/

typedef unsigned long RANDOMTYPE;

void InitRandom( RANDOMTYPE);
RANDOMTYPE Random();
double RandomFloating();
