#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "Genome_profile_aux.h"
#include "Poisson_score_aux.h"

#define NAMEPEAKS "Peaks"
#define EXT ".bed"

int Ini_peaks;

static void Profiles(double *Prof_peak, double **Prof_score,
		     double *Discriminant_score,
		     long ***xprof, float ***yprof, long **nprof,
		     char **name_prof, int N_prof,
		     struct frag *peaks, int N_peaks,
		     char *name_out, int PRINT);
static int Find_peaks(struct frag *ori,
		      long **x_scr, float **y_scr, long *nn, //float **z_scr
		      int Ncr, float Thr, int WINHALF);

static int Copy_peaks(struct frag *ori_ini, struct frag *ori, int N_ori);

static void Print_Peaks_new(struct frag *ori, char *nameout, char *nameold);
static void Print_Peaks_nomatch(struct frag *ori_old, int N_ori_old,
				char *nameout);
static void Print_Peaks(struct frag *ori, char *nameout);
void New_peaks(struct frag *peak2, int *N_new,
	       struct frag *peak1, int N);
void Confirmed_peaks(struct frag *peak2, int *N_new,
		     struct frag *peak1, int N);

int Get_peaks(double *Discriminant_score,
	      double **Prof_score, double *Prof_ori,
	      long **x_scr, float **y_scr, long *nn, int Ncr,
	      struct frag *ori_old, int N_ori_old,
	      long ***xprof, float ***yprof, long **nprof,
	      char **name_prof, int N_prof,
	      int DCLUST, float Size_Min, int WINHALF,
	      int WINSIZE, int Stat_Comp, int DTOL, float MC,
	      char *file_old, float Thr, int PRINT)
{
  struct frag ori[ORIMAX], ori_ini[ORIMAX], *ori1;
  int joined[ORIMAX], removed[ORIMAX];
  int N_ori=Find_peaks(ori, x_scr, y_scr, nn, Ncr, Thr, WINHALF); //z_scr 
   
  // Copy origins before joining
  int N_ori_ini=Copy_peaks(ori_ini, ori, N_ori);

  // Make clusters
  // Make_cluster_4(ori, N_ori, joined, DCLUST);
  N_ori=Make_cluster_1(ori, N_ori, joined, DCLUST);
  if(N_ori<2*Ncr){
    printf("Too few peaks found with threshold= %.2f\n", Thr); 
    return(0);
  }

  // Eliminate small fragments
  if(0 &&(Size_Min > 1)){
    float Size_min=(float)WINSIZE*Size_Min;
    N_ori=Remove_fragments(ori, N_ori, removed, Size_min);
  }

  // Output
  /* printf("Threshold window Positives");
     for(p=0; p<N_prof; p++)printf(" %s", name_prof[p]);
     printf("\n");
     printf("%4.1f %3d  %3d\n", Thr, WINDOW, N_ori);*/
  printf("%4.1f ", Thr);

  int N_ori_max=N_ori_ini;
  if(N_ori_old>N_ori_max){N_ori_max=N_ori_old;}

  /*
  // Statistics before joining
  Profile_score(Prof_ori,Prof_score, NULL, NULL,
  Discriminant_score,xprof,yprof,nprof,N_prof,ori_ini);
  Sizediff_stat(ori_ini, Prof_ori, Prof_score, N_prof,
  name_prof, "oridist_ini.dat");
  */

  // Profile score for all genome

  char nameout[200];
  if(PRINT){
    // Random origins
    struct frag *oriran=Extract_peaks(ori, N_ori, Ncr); //NULL
    Profiles(Prof_ori, Prof_score, Discriminant_score,
	     xprof, yprof, nprof, name_prof, N_prof,
	     oriran, N_ori, "Properties_Random.dat", PRINT);
    sprintf(nameout, "%s_Random_%d%s", NAMEPEAKS, N_ori, EXT);
    Print_Peaks(oriran, nameout); free(oriran);
  }

  // Statistics after joining
  Profiles(Prof_ori, Prof_score, Discriminant_score,
	   xprof, yprof, nprof, name_prof, N_prof,
	   ori, N_ori, "Properties_Peaks.dat", PRINT);

  // Compare with old predictions, if any
  char namefound[200]; FILE *file_found;
  if(N_ori_old){
    printf("Comparing with previous peaks\n");
    float over_1, over_2, over_1r, over_2r;
    int n_match=0, n_match_old=0;
    float dist=Dist_peaks(ori, N_ori, ori_old, N_ori_old);
    printf(" %.0f", dist);
    dist=Dist_peaks(ori_old, N_ori_old, ori, N_ori);
    printf(" %.0f", dist);

    // Overlap with random peaks
    struct frag *ori2=Extract_peaks(ori_old, N_ori_old, Ncr);
    Count_matches(&n_match,&n_match_old,DTOL,ori,N_ori,ori2,N_ori_old);
    over_1r=(float)n_match_old/N_ori_old;
    over_2r=(float)n_match/N_ori;
    free(ori2);

    // Overlap with predictions
    Count_matches(&n_match, &n_match_old,DTOL,ori,N_ori,ori_old,N_ori_old);
    over_1=(float)n_match_old/N_ori_old;
    over_2=(float)n_match/N_ori;

    printf("  %.3f %.3f %.3f",  over_1, over_2, over_1*over_2);
    printf("  %.1f %.1f %.1f",  over_1/over_1r, over_2/over_2r,
	   over_1*over_2/(over_1r*over_2r));
  }
  printf("\n");

  if(PRINT){

    // Print peaks
    sprintf(nameout, "%s_ALL_W%d_T%.1f_J%d%s",
	    NAMEPEAKS, WINSIZE, Thr, DCLUST, EXT);
    Print_Peaks(ori, nameout);


    if(N_ori_old){
      sprintf(nameout, "%s_notfound%s", file_old, EXT);
      Print_Peaks_nomatch(ori_old, N_ori_old, nameout);

      char nameold[200];
      sprintf(nameold, "%s_OLD_W%d_T%.1f_J%d%s",
	      NAMEPEAKS, WINSIZE, Thr, DCLUST, EXT);
      sprintf(nameout, "%s_NEW_W%d_T%.1f_J%d%s",
	      NAMEPEAKS, WINSIZE, Thr, DCLUST, EXT);
      Print_Peaks_new(ori, nameout, nameold);

      // Statistics of peaks present / not present in previous set
      int N_peak=0;
      struct frag *peak2=malloc(N_ori*sizeof(struct frag));
      printf("Profiles of common/new/unconfirmed peaks\n");
      New_peaks(peak2, &N_peak, ori, N_ori);
      Profiles(Prof_ori, Prof_score, Discriminant_score,
	       xprof, yprof, nprof, name_prof, N_prof,
	       peak2, N_peak, "Properties_NewPeaks.dat", PRINT);

      Confirmed_peaks(peak2, &N_peak, ori, N_ori);
      Profiles(Prof_ori, Prof_score, Discriminant_score,
	       xprof, yprof, nprof, name_prof, N_prof,
	       peak2, N_peak, "Properties_CommonPeaks.dat", PRINT);
      free(peak2);

      peak2=malloc(N_ori_old*sizeof(struct frag));
      New_peaks(peak2, &N_peak, ori_old, N_ori_old);
      Profiles(Prof_ori, Prof_score, Discriminant_score,
	       xprof, yprof, nprof, name_prof, N_prof,
	       peak2, N_peak, "Properties_UnconfirmedPeaks.dat", PRINT);

      Profiles(Prof_ori, Prof_score, Discriminant_score,
	       xprof, yprof, nprof, name_prof, N_prof,
	       ori_old, N_ori_old, "Properties_ReferencePeaks.dat", 1);
      free(peak2);

    }

    /************* Metaplots ******************/
    int p;
    for(p=0; p<N_prof; p++){
      Plot_profile(ori, p, xprof[p], yprof[p], nprof[p],
		   name_prof[p], "Metaplots_peaks.dat");
    }
    if(N_ori_old){
      for(p=0; p<N_prof; p++){
	Plot_profile(ori_old, p, xprof[p], yprof[p], nprof[p],
		     name_prof[p], "Metaplots_reference.dat");
      }
    }

  }
  return(N_ori);
}

void Profiles(double *Prof_peak, double **Prof_score,
	      double *Discriminant_score,
	      long ***xprof, float ***yprof, long **nprof,
	      char **name_prof, int N_prof,
	      struct frag *peaks, int N_peaks, char *name_out, int PRINT)
{
  struct fragshort *fshort=Fragshort(peaks, N_peaks);
  Profile_score(Prof_peak, Prof_score, NULL, NULL, Discriminant_score,
		xprof, yprof, nprof, N_prof, fshort, N_peaks);
  Sizediff_stat(peaks, Prof_peak, Prof_score, Discriminant_score,
		N_prof, name_prof, name_out, PRINT);
  free(fshort);
}

int Find_peaks(struct frag *ori,
	       long **x_scr, float **y_scr, long *nn, //float **z_scr
	       int Ncr, float Thr, int WINHALF)
{
  int N_ori=0, i, k;
  struct frag *ori1;
  for(k=0; k<Ncr; k++){
    int sel=0, cr=k+1; 
    long *x=x_scr[k];
    float *z=y_scr[k];
    for(i=0; i<nn[k]; i++){
      if(z[i]>Thr){
	// Start peak
	if(sel==0){
	  sel=1; ori1=ori+N_ori; ori1->ini=x[i]-WINHALF; ori1->chr=cr;
	  //ori1->xsum=0; ori1->norm=0;
	}
	//ori1->xsum+=x[i]*z[i]; ori1->norm+=z[i];
	if(N_ori>ORIMAX){
	  printf("ERROR, too many peaks (increase ORIMAX = %d)\n",
		 ORIMAX); exit(8);
	}
      }else if(sel){
	ori1->end=x[i-1]+WINHALF; sel=0;
	if(ori1->end - ori1->ini >=MINSIZE){N_ori++;}
	//else{ori1->xsum=0; ori1->norm=0;}
      }
    }
    if(sel){
      ori1->end=x[i-1]+WINHALF; sel=0;
      if(ori1->end - ori1->ini >=MINSIZE){N_ori++;}
      //else{ori1->xsum=0; ori1->norm=0;}
    }
    // printf("Chromosome %2d, origins: %d\n", k+1, N_ori);
  }
  for(i=0; i<N_ori; i++)Set_ori(ori+i, i);
  ori[N_ori-1].next=NULL;
  return(N_ori);
}

 int Copy_peaks(struct frag *ori_ini, struct frag *ori, int N_ori)
{
  struct frag *ori1=ori_ini; int i;
  for(i=0; i<N_ori; i++){
    *ori1=ori[i]; ori1->next=ori1+1; ori1++;
  }
  ori_ini[N_ori-1].next=NULL;
  return(N_ori);
}

void Print_Peaks(struct frag *ori, char *nameout)
{
  FILE *file_out=Open_file_w(nameout);
  //fprintf(file_out, "%s", parameters);
  struct frag *ori1=ori; int Np=0;
  while(ori1!=NULL){
    Print_peak(file_out, *ori1); Np++; ori1=ori1->next;
  }
  fclose(file_out);
  printf("Printing %d peaks in %s\n", Np, nameout);
}

void Print_Peaks_nomatch(struct frag *ori_old, int N_ori_old, char *nameout)
{ 
  int i, Np=0;
  FILE *file_out=Open_file_w(nameout);
  for(i=0; i<N_ori_old; i++){
    if(ori_old[i].match==0){
      Print_peak(file_out, ori_old[i]); Np++;
    }
  }
  fclose(file_out);
  printf("Printing %d previous not confirmed peaks in %s\n",Np, nameout);
}

void Print_Peaks_new(struct frag *ori, char *nameout, char *nameold)
{
  FILE *file_out=Open_file_w(nameold);
  FILE *file_new=Open_file_w(nameout);
  struct frag *ori1=ori; int Np=0, Np_new=0;
  while(ori1!=NULL){
    if(ori1->match==0){
      Print_peak(file_new, *ori1); Np_new++;
    }else{
      Print_peak(file_out, *ori1); Np++;
    }
    ori1=ori1->next;
  }
  fclose(file_out); fclose(file_new); 
  printf("Printing %d previous confirmed peaks in %s\n",
	 Np, nameold);
  printf("Printing %d new peaks in %s\n",
	 Np_new, nameout);
}

void New_peaks(struct frag *peak2, int *N_new, struct frag *peak, int N)
{
  struct frag *peak1=peak;
  struct frag *p2=peak2; int i; *N_new=0;
  while(peak1!=NULL){
    if(peak1->match==0){
      *p2=*peak1; p2->lab=(*N_new); p2->next=p2+1;
      p2++; (*N_new)++;
    }
    peak1=peak1->next;
  }
  (p2-1)->next=NULL;
}

void Confirmed_peaks(struct frag *peak2, int *N_new,
		     struct frag *peak, int N)
{
  struct frag *peak1=peak;
  struct frag *p2=peak2; int i; *N_new=0;
  while(peak1!=NULL){
    if(peak1->match){
      *p2=*peak1; p2->lab=(*N_new); p2->next=p2+1;
      p2++; (*N_new)++;
    }
    peak1=peak1->next;
  }
  (p2-1)->next=NULL;
}


