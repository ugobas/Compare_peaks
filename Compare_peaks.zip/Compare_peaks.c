#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "Genome_profile_aux.h"

#define CODE "Compare_peaks"
#define TOLDEF 0
#define NCH 1000
int PEAKSIZE, MINSIZE;
int CENTER=0; // Center first set of peaks?

static void help();
static int Get_chr(struct frag *peak, int N);
static int Get_input(char *file_p1, char *file_p2, char *file_o,
		     int *DTOL, int *PRINT, int *SEPARATE, int *nran,
		     int argc, char **argv);
extern void Rank_frags(struct frag *frags, int n, int Nchr);

extern int Unify_peaks(struct frag *ori,
		       struct frag *ori1, int N_ori1,
		       struct frag *ori2, int N_ori2,
		       float DTOL);
void Reduce_to_center(struct frag *frags, int n);

int nran=100;

int main(int argc, char **argv)
{
  int DTOL=TOLDEF;
  int PRINT=0, SEPARATE=0;
  PEAKSIZE=PEAKSIZE_DEF;
  MINSIZE=0;
  char file_p1[NCH], file_p2[NCH], file_o[NCH];
  Get_input(file_p1, file_p2, file_o, &DTOL, &PRINT, &SEPARATE, &nran,
	    argc, argv);
 
  // Read peaks 1
  long N_peak_1=0;
  printf("Reading %s\n", file_p1);
  struct frag *peak_1=Read_frags(&N_peak_1, file_p1, 100);
  int Nchr_1=Get_chr(peak_1, N_peak_1);
  Rank_frags(peak_1, N_peak_1, Nchr_1); 
  double size_1=Mean_size(peak_1, N_peak_1);

  if(CENTER)Reduce_to_center(peak_1, N_peak_1);

  // Read peaks 2
  long N_peak_2=0;
  printf("Reading %s\n", file_p2);
  struct frag *peak_2=Read_frags(&N_peak_2, file_p2, 100);
  int Nchr_2=Get_chr(peak_2, N_peak_2);
  Rank_frags(peak_2, N_peak_2, Nchr_2);
  double size_2=Mean_size(peak_2, N_peak_2);
  if((N_peak_1==0)||(N_peak_2==0)){
    printf("Nothing to do, one of the sets has 0 peaks.\n");
    printf("N1= %d N2=%d\n", N_peak_1, N_peak_2); exit(8);
  }
  int Nchr=Nchr_1;
  if(Nchr_1!=Nchr_2){
    printf("ERROR, different number of chromosomes: %d and %d\n",
	   Nchr_1, Nchr_2); //exit(8);
    if(Nchr_2>Nchr)Nchr=Nchr_2;
  }

  int i;
  for(i=0; i<N_peak_1; i++)peak_1[i].x0=(peak_1[i].ini+peak_1[i].end)/2;
  for(i=0; i<N_peak_2; i++)peak_2[i].x0=(peak_2[i].ini+peak_2[i].end)/2;


  char *file_1=Remove_dir(file_p1);
  char *file_2=Remove_dir(file_p2);
  char namefound[NCH]; FILE *file_found;
  sprintf(namefound, "%s_match.bed", file_2);

  float over_1=0, over_2=0, dist1=0, dist2=0;
  int n_match_1=0, n_match_2=0;
  double dc1=0, dc2=0, dr1=0, dr2=0, d1, d2;
  // distance between centers of matching peaks

  // Compare
  printf("# Peaks_1: %s %d peaks size %.4g\n", file_1, N_peak_1, size_1);
  printf("# Peaks_2: %s %d peaks size %.4g\n", file_2, N_peak_2, size_2);
  printf("#match over dcenter dist size set\n");

  // Overlap with predictions
  // Count_matches(&n_match_1,&n_match_2,DTOL,peak_1,N_peak_1,peak_2,N_peak_2);
  int strand_1=0, strand_2=0;
  n_match_1=Sum_match_d(&dc1,&dist1,&strand_1, peak_1,N_peak_1,peak_2,DTOL);
  n_match_2=Sum_match_d(&dc2,&dist2,&strand_2, peak_2,N_peak_2,peak_1,DTOL);
  over_1=(float)n_match_1/N_peak_1;
  over_2=(float)n_match_2/N_peak_2;
  float p_strand_1=strand_1/(float)n_match_1;
  float p_strand_2=strand_2/(float)n_match_2;

  printf("overlap1:\t%d\t%.3g\t%.0f\t%.0f\t%s\t%d\t%.0f\n",
	 n_match_1, over_1, dc1, dist1, file_1, N_peak_1, size_1);
  printf("overlap2:\t%d\t%.3g\t%.0f\t%.0f\t%s\t%d\t%.0f\n",
	 n_match_2, over_2, dc2, dist2, file_2, N_peak_2, size_2);
  if((peak_1[0].strand!='\0')&&(peak_2[0].strand!='\0')){
    printf("same_strand1: %.4f same_strand2: %.4f\n", p_strand_1, p_strand_2);
  }else{
    printf("WARNING, no strand information found\n");
    printf("Peaks1: %c\n", peak_1[0].strand);
    printf("Peaks2: %c\n", peak_2[0].strand);
  }

  if(PRINT){

    struct frag *peak; int is;
    char name_o[200], name_o2[200], *f1, *f2;
    for(is=1; is<=2; is++){
      if(is==1){peak=peak_1; f1=file_1; f2=file_2;}
      else{peak=peak_2; f1=file_2; f2=file_1;}

      sprintf(name_o, "%s_Intersect_%s.bed", f1, f2);
      FILE *file_I=fopen(name_o, "w");
      sprintf(name_o2, "%s_Unique_%s.bed", f1, f2);
      FILE *file_U=fopen(name_o2, "w");
 
      int ni=0, nu=0;
      while(peak!=NULL){
	if(peak->match==0){
	  fprintf(file_U,"%d\t%d\t%d\n",peak->chr, peak->ini, peak->end);
	  nu++;
	}else{
	  fprintf(file_I,"%d\t%d\t%d\n",peak->chr, peak->ini, peak->end);
	  ni++;
	}
	peak=peak->next;
      }
      fclose(file_U);
      fclose(file_I);
      printf("Printing %d intersetting peaks in %s\n", ni, name_o);
      printf("Printing %d unique peaks in %s\n", nu, name_o2);
    }

    struct frag *peak_3=malloc((N_peak_1+N_peak_2)*sizeof(struct frag));
    int Np_3=Unify_peaks(peak_3, peak_1, N_peak_1, peak_2, N_peak_2, DTOL);
    sprintf(name_o, "%s_Union.bed", file_o);
    FILE *file_Union=fopen(name_o, "w");
    printf("Printing union of %d peaks from %d in %s\n",
	   Np_3, N_peak_1+N_peak_2, name_o);
    peak=peak_3;
    while(peak!=NULL){
      fprintf(file_Union, "%d\t%d\t%d\n",
	      peak->chr, peak->ini, peak->end);
      peak=peak->next;
    }
    fclose(file_Union);
    free(peak_3);
  }

  // Overlap with random predictions
  double mran1=0, dran1=0, pran1=0, mran2=0, dran2=0, pran2=0;
  int kran=0; float dran=0;
  if(nran){
    printf("# Extracting %d random sets with same size\n", nran);
    printf("#k\tpran1\tover_1/ran\td1/ran\tpran2\tover_2/ran\td2/ran\n");
    while(kran<nran){   
      struct frag *fran=Extract_peaks(peak_2, N_peak_2, Nchr);
      int m=Sum_match_d(&d1, &dran, NULL, peak_1, N_peak_1, fran, DTOL);
      mran1+=m; dran1+=dran; dr1+=d1; if(m>=n_match_1)pran1++;
      free(fran);
      fran=Extract_peaks(peak_1, N_peak_1, Nchr);
      m=Sum_match_d(&d2, &dran, NULL, peak_2, N_peak_2, fran, DTOL);
      mran2+=m; dran2+=dran; dr2+=d2; if(m>=n_match_2)pran2++;
      free(fran);
      kran++;
      printf("%d\t%.3f\t%.3f\t%.3g\t%.3f\t%.3f\t%.3g\n", kran,
	     pran1/kran, n_match_1*kran/mran1, dist1*kran/dran1,
	     pran2/kran, n_match_2*kran/mran2, dist2*kran/dran2);
    }
    if(pran1==0)pran1=0.5;
    if(pran2==0)pran2=0.5;
    printf("# Final results\n");
    printf("#set n size match over pran over/ran dist dist/ran d_center dc/ran set\n");
    printf("overlap1:\t%d\t%.0f\t%d\t%.3g\t%.3f\t%.3g\t%.0f\t%.2g\t%.0f\t%.2g\t%s\n",
	   N_peak_1, size_1, n_match_1, over_1, (pran1)/kran,
	   n_match_1*kran/mran1, dist1, dist1*kran/dran1, dc1, dc1*kran/dr1,
	   file_1);
    printf("overlap2:\t%d\t%.0f\t%d\t%.3g\t%.3f\t%.3g\t%.0f\t%.2g\t%.0f\t%.2g\t%s\n",
	   N_peak_2, size_2, n_match_2, over_2, (pran2)/kran,
	   n_match_2*kran/mran2, dist2, dist2*kran/dran2, dc2, dc2*kran/dr1,
	   file_2);
    printf("Tolerance: %d\n", DTOL);
    if((peak_1[0].strand!='\0')&&(peak_2[0].strand!='\0')){
      printf("same_strand1: %.4g same_strand2: %.4g\n", p_strand_1, p_strand_2);
    }else{
      printf("WARNING, no strand information found\n");
      printf("Peaks1: %c\n", peak_1[0].strand);
      printf("Peaks2: %c\n", peak_2[0].strand);
    }
  }

  char nameout[400];
  sprintf(nameout, "Overlap_%s_%s.dat", file_1, file_2);
  FILE *file_out=fopen(nameout, "w");
  printf("Writing %s\n", nameout);
  fprintf(file_out,
	  "#set n size match over pran over/ran dist dist/ran d_center dc/ran set\n");
  fprintf(file_out,
    "overlap1:\t%d\t%.0f\t%d\t%.3g\t%.3f\t%.3g\t%.0f\t%.2g\t%.0f\t%.2g\t%s\n",
    N_peak_1, size_1, n_match_1, over_1, (pran1)/kran,
    n_match_1*kran/mran1, dist1, dist1*kran/dran1, dc1, dc1*kran/dr1,
    file_1);
  fprintf(file_out,
    "overlap2:\t%d\t%.0f\t%d\t%.3g\t%.3f\t%.3g\t%.0f\t%.2g\t%.0f\t%.2g\t%s\n",
    N_peak_2, size_2, n_match_2, over_2, (pran2)/kran,
    n_match_2*kran/mran2, dist2, dist2*kran/dran2, dc2, dc2*kran/dr2,
    file_2);
  fprintf(file_out,"Tolerance: %d\n", DTOL);
  fclose(file_out);

  return(0);
}


int Get_input(char *file_p1, char *file_p2, char *file_o,
	      int *DTOL, int *PRINT, int *SEPARATE, int *nran,
	      int argc, char **argv)      // input
{
  int i, mp=0;
  if(argc<2)help();
  file_o[0]='\0';
  for(i=1; i<argc; i++){
    if(strncmp(argv[i], "-h", 2)==0){
      help();
    }else if(strncmp(argv[i], "-t", 2)==0){
      i++; sscanf(argv[i], "%d", DTOL);
      if(*DTOL<0){
	printf("WARNING, tolerance must be positive, keeping default %d\n",
	       TOLDEF); *DTOL=TOLDEF;
      }
      printf("Tolerance= %d\n", *DTOL);
    }else if(strncmp(argv[i], "-r", 2)==0){
      i++; int idum=0; sscanf(argv[i], "%d", &idum);
      if(idum<0){
	printf("WARNING, random samples cannot be negative, set to zero %d\n");
	idum=0;
      }
      *nran=idum; printf("Random samples= %d\n", *nran);
    }else if(strncmp(argv[i], "-p", 2)==0){
      printf("Printing common and unique set of peaks\n"); *PRINT=1;
    }else if(strncmp(argv[i], "-c", 2)==0){
      printf("Centering the first set of peaks\n"); CENTER=1;
    }else if(strncmp(argv[i], "-o", 2)==0){
      i++; sscanf(argv[i], "%s", file_o);
    }else if(mp==0){
      sscanf(argv[i], "%s", file_p1); mp++;
    }else if(mp==1){
      sscanf(argv[i], "%s", file_p2); mp++;
    }else{
      printf("ERROR, only two input files can be specified\n");
      help();
    }
  }
  if(mp!=2){
    printf("ERROR, two input files must be specified\n"); help();
  }
  if(file_o[0]=='\0')sprintf(file_o, "%s_%s", file_p1, file_p2);
  return(0);
}

void help(){
  printf("\nPROGRAM %s\n", CODE);
  printf("Author: Ugo Bastolla,\n");
  printf("Centro de Biologia Molecular Severo Ochoa\n");
  printf("(CSIC-UAM), Madrid Spain\n");
  printf("<ubastolla@cbm.csic.es>\n\n");
  printf("Compares two lists of genomic peaks, finding their matches\n");
  printf("and compares with random peaks with same number and size.\n");

  printf("Mandatory argument: path to two bed files\n");
  printf("Input files must be in .bed format: chromosome start end\n");
  printf("Options:\n");
  printf("   -t <tolerance> (in base pairs), default %d\n", TOLDEF);
  printf("   -r <number of random samples, default %d>\n", nran);
  printf("   -p Print common and unique set of peaks in bed format\n");
  printf("   -c Consider only center of first set of peaks\n");
  printf("   -o <output file>\n");
  printf("   -h Print this help\n");
  exit(8);
}

int Get_chr(struct frag *peak, int N){
  int Nchr=-1, i;
  for(i=0; i<N; i++)if(peak[i].chr>Nchr)Nchr=peak[i].chr;
  return(Nchr);
}

void Reduce_to_center(struct frag *frags, int n){
  int i; struct frag *peak=frags;
  for(i=0; i<n; i++){
    long x0=(peak->ini+peak->end)/2;
    peak->ini=x0; peak->end=x0; peak++;
  }
}
